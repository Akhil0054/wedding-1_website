


AOS.init();




// start navbar Selection
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});
// end navbar Selection




// start auto counting section 
let startTime = localStorage.getItem('startTime');

if (!startTime) {
    startTime = Date.now();
    localStorage.setItem('startTime', startTime);
} else {
    startTime = Number(startTime);
}

function updateClock() {
    const now = Date.now();
    const elapsed = Math.floor((now - startTime) / 1000); 

    const days = Math.floor(elapsed / 86400);
    const hours = Math.floor((elapsed % 86400) / 3600);
    const minutes = Math.floor((elapsed % 3600) / 60);
    const seconds = elapsed % 60;

    document.getElementById('days').textContent = String(days).padStart(2, '0');
    document.getElementById('hours').textContent = String(hours).padStart(2, '0');
    document.getElementById('minutes').textContent = String(minutes).padStart(2, '0');
    document.getElementById('seconds').textContent = String(seconds).padStart(2, '0');
}

setInterval(updateClock, 1000); 

// end auto counting section 